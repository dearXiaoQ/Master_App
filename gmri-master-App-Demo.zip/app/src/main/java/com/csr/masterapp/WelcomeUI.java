package com.csr.masterapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

import static com.csr.masterapp.utils.CacheUtils.getBoolean;

public class WelcomeUI extends Activity implements AdapterView.OnItemClickListener {

    private final static long ANIMATION_DURATION = 2000;

    private ImageView ic_logo;

    private static final String TAG = "WelcomeUI";

    public static final String KEY_FIRST_START = "is_first_start";//标记是否第一次打开的key

    private static final int REQUEST_ENABLE_BT = 1;

    // Adjust this value to control how long scan should last for. Higher values will drain the battery more.
    // Adjust this value in the derived class.
    protected long mScanPeriodMillis = 5000;

    ListView mScanListView = null;

    private static ArrayList<ScanInfo> mScanResults = new ArrayList<ScanInfo>();

    private static HashSet<String> mScanAddreses = new HashSet<String>();

    private static ScanResultsAdapter mScanResultsAdapter;

    private BluetoothAdapter mBtAdapter = null;

    private static Handler mHandler = new Handler();

    private Button mScanButton = null;

    private boolean mCheckBt = false;

    public static Activity mWelcomeUI;

    private static final int INDEX_UUID_1 = 5;
    private static final int INDEX_UUID_2 = 6;
    private static final byte UUID_1 = (byte) 0xF1;
    private static final byte UUID_2 = (byte) 0xFE;

    private ProgressBar pbar_Welcome;

    // number of connection
    private int scanAttempts = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //设置无标题
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);//去除状态栏
        setContentView(R.layout.welcome);

        boolean isFirstStart = getBoolean(this, KEY_FIRST_START, true);
        if (isFirstStart){
            Log.d(TAG, "进入引导页");
            Intent intent = new Intent(this, GuideUI.class);
            startActivity(intent);
            finish();
        }

        mWelcomeUI = this;
        ic_logo = (ImageView) this.findViewById(R.id.ic_logo);

        mScanListView = (ListView) this.findViewById(R.id.scanListView);
        mScanResultsAdapter = new ScanResultsAdapter(this, mScanResults);
        mScanListView.setAdapter(mScanResultsAdapter);
        mScanListView.setOnItemClickListener(this);

        mScanButton = (Button) findViewById(R.id.buttonScan);
        mScanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scanLeDevice(true);
            }
        });
        pbar_Welcome = (ProgressBar) findViewById(R.id.pbar_Welcome);

        final BluetoothManager btManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBtAdapter = btManager.getAdapter();

        // Register for broadcasts on BluetoothAdapter state change so that we can tell if it has been turned off.
        IntentFilter filter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
        this.registerReceiver(mReceiver, filter);
        checkEnableBt();

        if (mBtAdapter.isEnabled()) {
            scanLeDevice(true);
        }

        //透明动画
        AlphaAnimation alphaAnimation = new AlphaAnimation(0f, 1f);
        alphaAnimation.setDuration(ANIMATION_DURATION);

        //位移动画
        TranslateAnimation translateAnimation = new TranslateAnimation(
                Animation.RELATIVE_TO_SELF, 0f,
                Animation.RELATIVE_TO_SELF, 0f,
                Animation.RELATIVE_TO_SELF, -1f,
                Animation.RELATIVE_TO_SELF, 0f);
        translateAnimation.setDuration(ANIMATION_DURATION);

        //动画集合
        AnimationSet set = new AnimationSet(false);
        set.addAnimation(alphaAnimation);
        set.addAnimation(translateAnimation);

        ic_logo.startAnimation(set);

//        //监听动画执行
//        set.setAnimationListener(new WelcomAnimationListener());

    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    /**
     * When the Activity is resumed, clear the scan results list.
     */
    @Override
    protected void onResume() {
        super.onResume();
        clearScanResults();
        if (mCheckBt) {
            checkEnableBt();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        scanLeDevice(false);
        // Set flag to check Bluetooth is still enabled when we are resumed.
        // If we end up being destroyed this flag's state will be forgotten, but that's fine because then
        // onCreate will perform the Bluetooth check anyway.
        mCheckBt = true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(mReceiver);
    }


//    private void doNavgation() {
//        //页面跳转
//        boolean isFirstStart = getBoolean(this, KEY_FIRST_START, true);
//        if (isFirstStart){
//            Log.d(TAG, "进入引导页");
//            Intent intent = new Intent(this, GuideUI.class);
//            startActivity(intent);
//        }else{
//            Log.d(TAG, "进入主页");
//            Intent intent = new Intent(this, MainActivity.class);
//            startActivity(intent);
//        }
//        finish();
//    }

//    class WelcomAnimationListener implements Animation.AnimationListener {
//        protected static final long ANIMATION_DELAY = 2500;
//
//        @Override
//        public void onAnimationStart(Animation animation) {
//
//            new Thread(new Runnable() {
//                @Override
//                public void run() {
//                    //等待
//                    try {
//                        Thread.sleep(ANIMATION_DELAY);
//                    } catch (InterruptedException e) {
//                        e.printStackTrace();
//                    }
//
//                    doNavgation();
//                }
//            }).start();
//        }
//
//        @Override
//        public void onAnimationEnd(Animation animation) {
//        }
//
//        @Override
//        public void onAnimationRepeat(Animation animation) {
//        }
//    }

    /**
     * Handle Bluetooth connection when the user selects a device.
     * @TODO
     */
    protected void connectBluetooth(int i) {
        Intent intent = new Intent(this, MainActivity.class);
        // Try top 3 devices
        ArrayList<BluetoothDevice> devices = new ArrayList<>();
//        for (int i = 0; i < mScanResults.size() && i < 3; i++) {
        ScanInfo info = mScanResults.get(i);
        devices.add(mBtAdapter.getRemoteDevice(info.address));          //getRemoteDevice()返回相应的被指定蓝牙连接的远端设备。
//       }
        intent.putParcelableArrayListExtra(BluetoothDevice.EXTRA_DEVICE, devices);
        Log.i(TAG, "Devices : " + intent.putParcelableArrayListExtra(BluetoothDevice.EXTRA_DEVICE, devices));

        this.startActivity(intent);


    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        connectBluetooth(position);
    }

    /**
     *  Display a dialogue requesting Bluetooth to be enabled if it isn't already.
     */
    private void checkEnableBt() {
        if (mBtAdapter == null || !mBtAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        }
    }

    /**
     * Callback activated after the user responds to the enable Bluetooth dialogue.
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        mCheckBt = false;
        if (requestCode == REQUEST_ENABLE_BT && resultCode != RESULT_OK) {
            mScanButton.setVisibility(View.GONE);
            Toast.makeText(this, getString(R.string.bluetooth_not_enabled), Toast.LENGTH_LONG).show();
        }
    }

    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();

            if (action.equals(BluetoothAdapter.ACTION_STATE_CHANGED)) {
                final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR);
                if (state == BluetoothAdapter.STATE_OFF) {
                    Toast.makeText(context, getString(R.string.bluetooth_disabled), Toast.LENGTH_SHORT).show();
                    scanLeDevice(false);
                    clearScanResults();
                    mScanButton.setVisibility(View.GONE);
                } else if (state == BluetoothAdapter.STATE_ON) {
                    Toast.makeText(context, getString(R.string.bluetooth_enabled), Toast.LENGTH_SHORT).show();
                    mScanButton.setVisibility(View.VISIBLE);
                    mBtAdapter = ((BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE)).getAdapter();
                }
            }
        }
    };


    /**
     * Clear the cached scan results, and update the display.
     */
    private void clearScanResults() {
        mScanResults.clear();
        mScanAddreses.clear();
        // Make sure the display is updated; any old devices are removed from the ListView.
        mScanResultsAdapter.notifyDataSetChanged();
    }


    private Runnable scanTimeout = new Runnable() {
        @Override
        public void run() {
            mBtAdapter.stopLeScan(mLeScanCallback);
            pbar_Welcome.setVisibility(View.GONE);
            // Connect to the device with the smallest RSSI value
            if (!mScanResults.isEmpty()) {
                scanAttempts = 0;
//	            connectBluetooth();
            } else {
                Toast.makeText(getApplicationContext(), "没有发现可连接设备", Toast.LENGTH_SHORT).show();
            	mScanButton.setVisibility(View.VISIBLE);
                scanAttempts++;
                if (scanAttempts >= 2) {
                    //show an alert asking to reset the Bluetooth
                    askResetBluetooth();
                }
            }
        }
    };

    /**
     * Pop up an alert asking if the user want to reset the bluetooth
     */
    private void askResetBluetooth() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(WelcomeUI.this);

        alertDialogBuilder.setMessage("没有发现可连接设备,请重置蓝牙。");
        // set positive button: Yes message
        alertDialogBuilder.setPositiveButton("重  置", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                resetBluetooth();
                dialog.cancel();
            }
        });
        // set negative button: No message
        alertDialogBuilder.setNegativeButton("稍后处理", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // cancel the alert box and put a Toast to the user
                dialog.cancel();
            }
        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        // show alert
        alertDialog.show();
    }

    /**
     * Stop and Start the Bluetooth. We shoudn't use this method without user permission.
     */
    private void resetBluetooth() {
        if (mBtAdapter != null) {
            mBtAdapter.disable();
            mHandler.postDelayed(new Runnable() {

                @Override
                public void run() {
                    checkEnableBt();
                }
            }, 200);

        }
    }

    /**
     * Start or stop scanning. Only scan for a limited amount of time defined by SCAN_PERIOD.
     *
     * @param enable
     *            Set to true to enable scanning, false to stop.
     */
    private void scanLeDevice(final boolean enable) {

        if (enable) {
            // Stops scanning after a predefined scan period.
            mHandler.postDelayed(scanTimeout, mScanPeriodMillis);
            clearScanResults();     //清除搜索结果
            pbar_Welcome.setVisibility(View.VISIBLE);
            mBtAdapter.startLeScan(mLeScanCallback);
        } else {
            // Cancel the scan timeout callback if still active or else it may fire later.
            mHandler.removeCallbacks(scanTimeout);
            //setProgressBarIndeterminateVisibility(false);
            pbar_Welcome.setVisibility(View.GONE);
            mBtAdapter.stopLeScan(mLeScanCallback);
            mScanButton.setVisibility(View.VISIBLE);
        }
    }

    /**
     * Callback for scan results.
     */
    private BluetoothAdapter.LeScanCallback mLeScanCallback = new BluetoothAdapter.LeScanCallback() {
        @Override
        public void onLeScan(final BluetoothDevice device, final int rssi, final byte[] scanRecord) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (device.getName() == null) {
                        // Sometimes devices are seen with a null name and empirically connection
                        // to such devices is less reliable, so ignore them.
                        return;
                    }
                    // Check that this isn't a device we have already seen, and add it to the list.
                    if (!mScanAddreses.contains(device.getAddress())) {
                        if (device.getType() == BluetoothDevice.DEVICE_TYPE_LE &&
                                scanRecord[INDEX_UUID_1] == UUID_1 && scanRecord[INDEX_UUID_2] == UUID_2) {
                            ScanInfo scanResult = new ScanInfo(device.getName(), device.getAddress(), rssi);
                            mScanAddreses.add(device.getAddress());
                            mScanResults.add(scanResult);
                            Collections.sort(mScanResults);
                            mScanResultsAdapter.notifyDataSetChanged();
                        }
                    } else {
                        for (ScanInfo info : mScanResults) {
                            if (info.address.equalsIgnoreCase((device.getAddress()))) {
                                info.rssi = rssi;
                                Collections.sort(mScanResults);
                                mScanResultsAdapter.notifyDataSetChanged();
                                break;
                            }
                        }
                    }
                }
            });
        }
    };

    /**
     * The adapter that allows the contents of ScanInfo objects to be displayed in the ListView. The device name,
     * address, RSSI and the icon specified in appearances.xml are displayed.
     */
    private class ScanResultsAdapter extends BaseAdapter {
        private Activity activity;
        private ArrayList<ScanInfo> data;
        private LayoutInflater inflater = null;

        public ScanResultsAdapter(Activity a, ArrayList<ScanInfo> object) {
            activity = a;
            data = object;
            inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        public int getCount() {
            return data.size();
        }

        public Object getItem(int position) {
            return data.get(position);
        }

        public long getItemId(int position) {
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            View vi = convertView;
            if (convertView == null)
                vi = inflater.inflate(R.layout.scan_list_row, null);

            TextView nameText = (TextView) vi.findViewById(R.id.name);
            TextView addressText = (TextView) vi.findViewById(R.id.address);
            TextView rssiText = (TextView) vi.findViewById(R.id.rssi);

            ScanInfo info = (ScanInfo) data.get(position);
            nameText.setText(info.name);
            addressText.setText(info.address);
            if (info.rssi != 0) {
                rssiText.setText(String.valueOf(info.rssi) + "dBm");
            }
            return vi;
        }

        @Override
        public void notifyDataSetChanged() {
            // before notify. sort the data by RSSI.
            Collections.sort(data);

            super.notifyDataSetChanged();
        }
    }

    private class ScanInfo implements Comparable<ScanInfo> {
        public String name;
        public String address;
        public int rssi;

        public ScanInfo(String name, String address, int rssi) {
            this.name = name;
            this.address = address;
            this.rssi = rssi;
        }

        @Override
        public int compareTo(ScanInfo another) {
            final int BEFORE = -1;
            final int EQUAL = 0;
            final int AFTER = 1;

            if (rssi == another.rssi) return EQUAL;
            if (this.rssi < another.rssi) return AFTER;
            if (this.rssi > another.rssi) return BEFORE;

            return EQUAL;
        }
    }
}
