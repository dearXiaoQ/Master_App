
/******************************************************************************
 Copyright Cambridge Silicon Radio Limited 2014 - 2015.
 ******************************************************************************/

package com.csr.masterapp.device;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.csr.masterapp.DeviceController;
import com.csr.masterapp.R;

/**
 * Fragment used to configure devices. Handles assigning devices to groups, get firmware version, remove a device or
 * group, rename a device or group and add a new group. Contains two side by side CheckedListFragment fragments.
 * 
 */
public class DeviceListFragment extends Fragment implements View.OnClickListener {
    private static final String TAG = "DeviceListFragment";


    private View mRootView;

    private DeviceController mController;
    private Fragment mCurrentFragment;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        try {
            mController = (DeviceController) activity;
        }
        catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() + " must implement DeviceController callback interface.");
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }
    
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (mRootView == null) {
            mRootView = inflater.inflate(R.layout.device_list_fragment, container, false);
        }
        mRootView.findViewById(R.id.RHood).setOnClickListener(this);
        mRootView.findViewById(R.id.Ecookpan).setOnClickListener(this);
        mRootView.findViewById(R.id.Lamp).setOnClickListener(this);
        mRootView.findViewById(R.id.LSensor).setOnClickListener(this);
        mRootView.findViewById(R.id.SSensor).setOnClickListener(this);
        mRootView.findViewById(R.id.PIRSensor).setOnClickListener(this);
        return mRootView;
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onClick(View v) {
        mCurrentFragment = null;
        switch (v.getId()){
            case R.id.RHood:
                mCurrentFragment = new RHoodControlFragment();
                break;
            case R.id.Ecookpan:
                mCurrentFragment = new EcookpanFragment();
                break;
            case R.id.Lamp:
                mCurrentFragment = new LightControlFragment();
                break;
            case R.id.LSensor:
                mCurrentFragment = new LSensorFragment();
                break;
            case R.id.SSensor:
                mCurrentFragment = new SSensorFragment();
                break;
            case R.id.PIRSensor:
                mCurrentFragment = new PIRSensorFragment();
                break;
        }

        if (mCurrentFragment != null) {
            FragmentManager Manager = getActivity().getSupportFragmentManager();
            Manager.beginTransaction().addToBackStack(null).replace(R.id.main_container_content, mCurrentFragment).commit();
        }
    }
}
