package com.csr.masterapp.fragment;

import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;

import com.csr.masterapp.BaseFragment;
import com.csr.masterapp.MainActivity;
import com.csr.masterapp.R;
import com.csr.masterapp.base.MenuController;
import com.csr.masterapp.utils.UIUtils;

import java.util.List;

/**
 * 项目名称：MasterApp
 * 类描述：
 * 创建人：11177
 * 创建时间：2016/6/21 10:13
 * 修改人：11177
 * 修改时间：2016/6/21 10:13
 * 修改备注：
 */
public class MenuFragment extends BaseFragment implements AdapterView.OnItemClickListener {

    private String[] mMenuPics;
    private int[] mMenuIcons;

    private MenuListAdapter mAdapter;

    private ListView mListView;

    private int mCurrentMenu;

    private List<MenuController> mMenuControllers;

    @Override
    protected View initView() {
        mListView = new ListView(mActivity);
        mListView.setBackgroundColor(Color.WHITE);
        mListView.setOnItemClickListener(this);
        return mListView;
    }

    @Override
    protected void initData() {
        String[] mMenuData = UIUtils.getStringArray(R.array.menu_pics);
        int[] mMenuDatas = {R.drawable.qq, R.drawable.weixin, R.drawable.sina, R.drawable.toutiao,
                            R.drawable.taobao, R.drawable.leshi, R.drawable.xiami, R.drawable.iqiyi };

        //加菜单数据
        setData(mMenuData, mMenuDatas);

    }

    public void setData(String[] data, int[] icos) {

        this.mMenuPics = data;
        this.mMenuIcons = icos;
        mCurrentMenu = 0;

        //初始化menu
        mAdapter = new MenuListAdapter();
        mListView.setAdapter(mAdapter);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        //实体改变
        MainActivity ui = (MainActivity) mActivity;

        //对应实体的内容要改变
        ContentFragment contentFragment = ui.getContentFragment();
        contentFragment.switchMenu(position);

        //设置当前选中的菜单
        mCurrentMenu = position;

        // ui刷新
        mAdapter.notifyDataSetChanged();
    }

    class MenuListAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            if (mMenuIcons != null) {
                return mMenuIcons.length;
            }
            return 0;
        }

        @Override
        public Object getItem(int position) {
            if (mMenuIcons != null) {
                return mMenuIcons[position];
            }
            return null;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder = null;
            if(convertView == null){
                convertView = View.inflate(mActivity, R.layout.item_menu, null);
                holder = new ViewHolder();
                convertView.setTag(holder);

                holder.iv = (ImageView) convertView;
            }else{
                holder = (ViewHolder) convertView.getTag();
            }

            holder.iv.setImageResource(mMenuIcons[position]);
            holder.iv.setEnabled(mCurrentMenu == position);

            return convertView;
        }
    }

    class ViewHolder{
        ImageView iv;
    }
}
