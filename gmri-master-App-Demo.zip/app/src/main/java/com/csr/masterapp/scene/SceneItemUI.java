package com.csr.masterapp.scene;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.csr.masterapp.R;
import com.csr.masterapp.database.DataBaseDataSource;
import com.csr.masterapp.entities.DeviceDes;
import com.csr.masterapp.entities.DeviceStream;
import com.csr.masterapp.entities.SingleDevice;
import com.csr.masterapp.scene.util.SceneItemModel;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * 项目名称：MasterApp v3
 * 类描述：添加任务列表
 * 创建人：11177
 * 创建时间：2016/7/8 11:39
 * 修改人：11177
 * 修改时间：2016/7/8 11:39
 * 修改备注：
 */

public class SceneItemUI extends Activity implements AdapterView.OnItemClickListener {

    private HashMap<String, DeviceStream> mStreams;
    private DataBaseDataSource mDataBase;

    private ListView mListView;
    private ListView desListView;

    private DeviceListAdapter deviceListAdapter;

    private ArrayList<SingleDevice> mSingleTaskDevices;

    private static final String TAG = "SceneItemUI";

    private AlertDialog.Builder builder;
    private ArrayList<DeviceDes> manuSet;
    private int mDeviceId;
    private String mStreamName;
    private AlertDialog dialog;
    private Integer mStreamType;
    private Integer mDataType;
    private TextView mTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_list);
        mDataBase = new DataBaseDataSource(this);
        initView();
        initData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private void initData() {
        Intent intent = getIntent();
        mStreamType = intent.getIntExtra("type", -1);
        if (mStreamType == -1) {
            finish();
            return;
        }
        mTitle.setText(mStreamType == 0 ? "启动条件" : "执行任务");

        mSingleTaskDevices = new ArrayList<SingleDevice>();
        mStreams = new HashMap<String, DeviceStream>();
        for (DeviceStream streams : mDataBase.getDeviceStream()) {
            if (streams.getType() == mStreamType) {
                mStreams.put(streams.getshortname(), streams);
            }
        }

        for (SingleDevice devices : mDataBase.getAllSingleDevices()) {
            //获取设备基本信息
            if (mStreams.containsKey(devices.getShortName().trim())) {
                mSingleTaskDevices.add(devices);
            }
        }

        //加载数据
        deviceListAdapter = new DeviceListAdapter();
        mListView.setAdapter(deviceListAdapter);
    }

    private void initView() {
        mTitle = ((TextView) findViewById(R.id.header_tv_title));
        mTitle.setText("设备联动");
        findViewById(R.id.header_btn_ok).setVisibility(View.GONE);

        mListView = (ListView) findViewById(R.id.device_list_view);
        findViewById(R.id.header_iv_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        mListView.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        if (mSingleTaskDevices == null) {
            return;
        }

        String shortname = mSingleTaskDevices.get(position).getShortName().trim();
        mDataType = mStreams.get(shortname).getData_type();
        manuSet = mStreams.get(shortname).getManu_set();

        String unit = mStreams.get(shortname).getUnit() == null ? "":mStreams.get(shortname).getUnit();
        String unit_symbol = mStreams.get(shortname).getUnit_symbol() == null ? "":mStreams.get(shortname).getUnit_symbol();
        if (unit == "" && unit_symbol != "") {
            unit = unit_symbol;
        }

        if (mStreamType == 0 && mDataType == 1) {
            if (manuSet == null) {
                manuSet = new ArrayList<DeviceDes>();
                int max_value = mStreams.get(shortname).getMax_value();
                int min_value = mStreams.get(shortname).getMin_value();
                int increment = mStreams.get(shortname).getIncrement();
                int value;
                for (int i = 0; i < (max_value - min_value + 1) / increment; i++) {
                    value = min_value + increment * i;
                    if (value > max_value) {
                        return;
                    }
                    manuSet.add(new DeviceDes(i - 1, mStreams.get(shortname).getStream_id(), "小于" + value + unit, value, "<"));
                    manuSet.add(new DeviceDes(i - 1, mStreams.get(shortname).getStream_id(), "大于" + value + unit, value, ">"));
                }
            }
        }

        mDeviceId = mSingleTaskDevices.get(position).getDeviceId();
        mStreamName = mSingleTaskDevices.get(position).getName().trim();

        //弹出对话框
        builder = new AlertDialog.Builder(SceneItemUI.this);
        builder.setTitle("设置参数");

        View itemDes = View.inflate(SceneItemUI.this, R.layout.ly_item_des, null);
        builder.setView(itemDes);
        desListView = (ListView) itemDes.findViewById(R.id.des_list_view);
        final DesListAdapter DesListAdapter = new DesListAdapter();
        desListView.setAdapter(DesListAdapter);

        builder.create();
        dialog = builder.show();

        desListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                dialog.dismiss();

                if (manuSet != null) {
                    SceneItemModel sceneItem = new SceneItemModel(mDeviceId, mStreamName, manuSet.get(position).getKey(), manuSet.get(position).getValue());
                    if (manuSet.get(position).getComparison_opt() != null ) {
                        sceneItem.setComparison_opt(manuSet.get(position).getComparison_opt());
                    }
                    Intent intent = new Intent();
                    intent.putExtra("sceneItem", sceneItem);
                    SceneItemUI.this.setResult(mStreamType, intent);
                    SceneItemUI.this.finish();
                }
            }
        });
    }

    class DeviceListAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            if (mSingleTaskDevices != null) {
                return mSingleTaskDevices.size();
            }
            return 0;
        }

        @Override
        public Object getItem(int position) {
            if (mSingleTaskDevices != null) {
                return mSingleTaskDevices.get(position);
            }
            return null;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder = null;
            if (convertView == null) {
                holder = new ViewHolder();
                convertView = View.inflate(SceneItemUI.this, R.layout.item_device, null);
                convertView.setTag(holder);
                holder.deviceName = (TextView) convertView.findViewById(R.id.tv_device_name);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }

            holder.deviceName.setText(mSingleTaskDevices.get(position).getName());
            return convertView;
        }

    }

    class ViewHolder {
        TextView deviceName;
    }

    class DesListAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            if (manuSet != null) {
                return manuSet.size();
            }
            return 0;
        }

        @Override
        public Object getItem(int position) {
            if (manuSet != null) {
                return manuSet.get(position);
            }
            return null;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            DesViewHolder holder = null;
            if (convertView == null) {
                holder = new DesViewHolder();
                convertView = View.inflate(SceneItemUI.this, R.layout.item_list, null);
                convertView.setTag(holder);
                holder.taskName = (TextView) convertView.findViewById(R.id.tv_list_name);
            } else {
                holder = (DesViewHolder) convertView.getTag();
            }

            holder.taskName.setText(manuSet.get(position).getKey());
            return convertView;
        }
    }

    class DesViewHolder {
        TextView taskName;
    }

}
