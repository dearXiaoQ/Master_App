
/******************************************************************************
 Copyright Cambridge Silicon Radio Limited 2014 - 2015.
 ******************************************************************************/
 
package com.csr.masterapp.interfaces;

public interface SlideBarListener {
	public void onRelease();
}
