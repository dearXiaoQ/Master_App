package com.csr.masterapp.utils;

/**
 * 项目名称：MasterApp
 * 类描述：全局常量
 * 创建人：11177
 * 创建时间：2016/6/22 11:00
 * 修改人：11177
 * 修改时间：2016/6/22 11:00
 * 修改备注：
 */
public class Constans {
}
