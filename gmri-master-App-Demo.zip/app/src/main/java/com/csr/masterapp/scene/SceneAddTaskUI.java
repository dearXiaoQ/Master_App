package com.csr.masterapp.scene;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.csr.masterapp.R;
import com.csr.masterapp.entities.DeviceDes;
import com.csr.masterapp.entities.DeviceStream;
import com.csr.masterapp.scene.util.SceneItemModel;

import java.util.List;

/**
 * 项目名称：MasterApp v3
 * 类描述：添加任务列表
 * 创建人：11177
 * 创建时间：2016/7/8 11:39
 * 修改人：11177
 * 修改时间：2016/7/8 11:39
 * 修改备注：
 */

public class SceneAddTaskUI extends Activity implements AdapterView.OnItemClickListener {

    private ListView mListView;

    private Button mOk;

    private DeviceStream mTaskStreams;

    private TextView mTitle;

    private TaskListAdapter taskListAdapter;

    private List<DeviceDes> mDeviceDes;
    private int mDeviceId;
    private String mDeviceName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        initView();
        initData();
    }

    private void initView() {
        mTitle = (TextView) findViewById(R.id.header_tv_title);
        mOk = (Button) findViewById(R.id.header_btn_ok);

        mListView = (ListView) findViewById(R.id.task_list_view);
        mListView.setOnItemClickListener(this);

        findViewById(R.id.header_iv_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void initData() {
        Intent intent = getIntent();
        mTaskStreams = (DeviceStream) intent.getSerializableExtra("taskStreams");
        mDeviceDes = mTaskStreams.getManu_set();

        mDeviceName = intent.getStringExtra("name");
        mDeviceId = intent.getIntExtra("deviceId",-1);

        mTitle.setText(mDeviceName);
        if(mDeviceId == -1){
            Toast.makeText(getBaseContext(),"设备不存在",Toast.LENGTH_SHORT).show();
            finish();
        }


        //加载数据
        taskListAdapter = new TaskListAdapter();
        mListView.setAdapter(taskListAdapter);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if (mDeviceDes == null) {
            return;
        }

        DeviceDes des =  mDeviceDes.get(position);
        SceneItemModel taskScene = new SceneItemModel(mDeviceId, mDeviceName, des.getKey(), des.getValue());

        Intent intent = new Intent(getApplicationContext(), CreateSceneUI.class);
        intent.putExtra("taskScene", taskScene);
        intent.putExtra("from",1);
        startActivity(intent);
    }

    class TaskListAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            if (mDeviceDes != null) {
                return mDeviceDes.size();
            }
            return 0;
        }

        @Override
        public Object getItem(int position) {
            if (mDeviceDes != null) {
                return mDeviceDes.get(position);
            }
            return null;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            ViewHolder holder = null;

            if (convertView == null) {
                holder = new ViewHolder();
                convertView = View.inflate(getApplicationContext(), R.layout.item_list, null);
                convertView.setTag(holder);
                holder.taskName = (TextView) convertView.findViewById(R.id.tv_list_name);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }

            holder.taskName.setText(mDeviceDes.get(position).getKey());
            return convertView;
        }
    }

    class ViewHolder {
        TextView taskName;
    }
}
