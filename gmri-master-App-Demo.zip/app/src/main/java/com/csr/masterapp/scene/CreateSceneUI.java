package com.csr.masterapp.scene;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.csr.masterapp.R;
import com.csr.masterapp.database.DataBaseDataSource;
import com.csr.masterapp.scene.util.SceneItemModel;
import com.csr.masterapp.scene.util.SceneModel;

import java.util.ArrayList;

/**
 * 项目名称：MasterApp v3
 * 类描述：新建场景
 * 创建人：11177
 * 创建时间：2016/7/7 15:21
 * 修改人：11177
 * 修改时间：2016/7/7 15:21
 * 修改备注：
 */
public class CreateSceneUI extends Activity implements View.OnClickListener, TextWatcher, CompoundButton.OnCheckedChangeListener, AdapterView.OnItemLongClickListener {

    private ArrayList<SceneItemModel> mConditions;
    private ArrayList<SceneItemModel> mTasks;

    private Button mOk;
    private ListView mTaskListview;

    private ListView mConditionListview;
    private TaskItemListAdppter mTaskItemListAdppter;
    private ConditionItemListAdpter mConditionItemListAdpter;

    private static final String TAG = "CreateSceneUI";

    private Intent intentDeviceList;

    private EditText mSceneName;
    private Button mPositiveButton;
    private DataBaseDataSource mDataBase;
    private int mIsSend;
    private SceneModel mScene;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_scene);
        mDataBase = new DataBaseDataSource(CreateSceneUI.this);
        mTasks = new ArrayList<SceneItemModel>();
        mConditions = new ArrayList<SceneItemModel>();
        initView();
        initData();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private void initView() {
        ((TextView) findViewById(R.id.header_tv_title)).setText("新增场景");
        mOk = (Button) findViewById(R.id.header_btn_ok);
        mOk.setText("保存");
        mOk.setOnClickListener(this);

        findViewById(R.id.header_iv_back).setOnClickListener(this);
        findViewById(R.id.iv_add_task).setOnClickListener(this);
        findViewById(R.id.iv_add_condition).setOnClickListener(this);

        mTaskListview = (ListView) findViewById(R.id.lv_task);
        mConditionListview = (ListView) findViewById(R.id.lv_condition);
    }

    private void initData() {

        mConditionItemListAdpter = new ConditionItemListAdpter();
        mConditionListview.setAdapter(mConditionItemListAdpter);
        mConditionListview.setOnItemLongClickListener(this);

        mTaskItemListAdppter = new TaskItemListAdppter();
        mTaskListview.setAdapter(mTaskItemListAdppter);
        mTaskListview.setOnItemLongClickListener(this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data != null) {
            SceneItemModel sceneItem = (SceneItemModel) data.getSerializableExtra("sceneItem");
            switch (resultCode) {
                case 0:
                    sceneItem.setType(0);
                    mConditions.add(sceneItem);
                    findViewById(R.id.tv_no_condition).setVisibility(mConditions.size() > 0 ? View.GONE : View.VISIBLE);
                    mConditionItemListAdpter.notifyDataSetChanged();
                    break;

                case 1:
                    sceneItem.setType(1);
                    mTasks.add(sceneItem);
                    findViewById(R.id.tv_no_task).setVisibility(mTasks.size() > 0 ? View.GONE : View.VISIBLE);
                    mTaskItemListAdppter.notifyDataSetChanged();
                    break;

            }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            default:
                return;
            case R.id.header_iv_back:
                if (mTasks.size() != 0 || mConditions.size() != 0) {
                    final AlertDialog.Builder builder = new AlertDialog.Builder(CreateSceneUI.this);
                    builder.setMessage("退出后修改将丢失，是否确定退出？");
                    builder.setPositiveButton("确定退出", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                        }
                    });
                    builder.setNegativeButton("取消", null);
                    builder.create().show();
                    return;
                }
                finish();
                return;
            case R.id.iv_add_condition:
                intentDeviceList = new Intent(CreateSceneUI.this, SceneItemUI.class);
                intentDeviceList.putExtra("type", 0);
                startActivityForResult(intentDeviceList, 0);
                return;
            case R.id.iv_add_task:
                intentDeviceList = new Intent(CreateSceneUI.this, SceneItemUI.class);
                intentDeviceList.putExtra("type", 1);
                startActivityForResult(intentDeviceList, 0);
                return;
            case R.id.header_btn_ok:
                if (mTasks.size() == 0) {
                    Toast.makeText(CreateSceneUI.this, "请添加任务", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (mConditions.size() == 0) {
                    Toast.makeText(CreateSceneUI.this, "请添加条件", Toast.LENGTH_SHORT).show();
                    return;
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(CreateSceneUI.this);
                builder.setTitle("设置场景名称");
                View diaName = View.inflate(CreateSceneUI.this, R.layout.dialog_insert_name, null);
                mSceneName = (EditText) diaName.findViewById(R.id.scene_et_name);
                CheckBox checkBox = (CheckBox) diaName.findViewById(R.id.scene_chk_msg);
                checkBox.setOnCheckedChangeListener(this);
                builder.setView(diaName);
                builder.setNegativeButton("取消", null);
                builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (mSceneName.getText().toString().trim().equals("")) {
                            Toast.makeText(CreateSceneUI.this, "场景名称不能为空", Toast.LENGTH_LONG).show();
                        } else {
                            //保存场景
                            mScene = new SceneModel(mSceneName.getText().toString().trim(), 1, 1, mIsSend, mConditions, mTasks);
                            Boolean insert_id = mDataBase.createOrUpdateScene(mScene);
                            if (insert_id) {
                                Toast.makeText(CreateSceneUI.this, "场景创建成功", Toast.LENGTH_SHORT).show();
                                finish();
                            } else {
                                Toast.makeText(CreateSceneUI.this, "场景创建失败", Toast.LENGTH_SHORT).show();
                            }
                        }

                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();

                mSceneName.addTextChangedListener(this);
                mPositiveButton = ((AlertDialog) dialog).getButton(AlertDialog.BUTTON_POSITIVE);
                if (mSceneName.getText().toString().equals("")) {
                    mPositiveButton.setEnabled(false);
                }
        }
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
    }

    @Override
    public void afterTextChanged(Editable s) {
        if (mSceneName.getText().toString().equals("")) {
            mPositiveButton.setEnabled(false);
        } else {
            mPositiveButton.setEnabled(true);
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        mIsSend = isChecked ? 1 : 0;
    }

    @Override
    public boolean onItemLongClick(final AdapterView<?> parent, View view, final int position, long id) {

        final AlertDialog.Builder builder = new AlertDialog.Builder(CreateSceneUI.this);
        builder.setPositiveButton("删除", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (parent.equals(mConditionListview)) {
                    mConditions.remove(position);
                    findViewById(R.id.tv_no_condition).setVisibility(mConditions.size() == 0 ? View.VISIBLE : View.GONE);
                    mConditionItemListAdpter.notifyDataSetChanged();
                }
                if (parent.equals(mTaskListview)) {
                    mTasks.remove(position);
                    findViewById(R.id.tv_no_task).setVisibility(mTasks.size() == 0 ? View.VISIBLE : View.GONE);
                    mTaskItemListAdppter.notifyDataSetChanged();
                }
            }
        });
        builder.create().show();
        return false;
    }

    class TaskItemListAdppter extends BaseAdapter {

        @Override
        public int getCount() {
            if (mTasks != null) {
                return mTasks.size();
            }
            return 0;
        }

        @Override
        public Object getItem(int position) {
            if (mTasks != null) {
                return mTasks.get(position);
            }
            return null;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder = null;

            if (convertView == null) {
                holder = new ViewHolder();
                convertView = View.inflate(getBaseContext(), R.layout.item_scene, null);
                convertView.setTag(holder);

                holder.deviceName = (TextView) convertView.findViewById(R.id.tv_list_name);
                holder.sceneName = (TextView) convertView.findViewById(R.id.tv_list_sec_name);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }
            holder.deviceName.setText(mTasks.get(position).getDeviceName());
            holder.sceneName.setText(mTasks.get(position).getKey());

            return convertView;
        }
    }

    class ConditionItemListAdpter extends BaseAdapter {

        @Override
        public int getCount() {
            if (mConditions != null) {
                return mConditions.size();
            }
            return 0;
        }

        @Override
        public Object getItem(int position) {
            if (mConditions != null) {
                return mConditions.get(position);
            }
            return null;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder = null;

            if (convertView == null) {
                holder = new ViewHolder();
                convertView = View.inflate(getBaseContext(), R.layout.item_scene, null);
                convertView.setTag(holder);

                holder.deviceName = (TextView) convertView.findViewById(R.id.tv_list_name);
                holder.sceneName = (TextView) convertView.findViewById(R.id.tv_list_sec_name);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }
            holder.deviceName.setText(mConditions.get(position).getDeviceName());
            holder.sceneName.setText(mConditions.get(position).getKey());

            return convertView;
        }
    }

    class ViewHolder {
        TextView deviceName;
        TextView sceneName;
    }

}
