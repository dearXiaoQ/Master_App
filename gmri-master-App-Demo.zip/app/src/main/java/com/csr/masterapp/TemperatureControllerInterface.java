
/******************************************************************************
 Copyright Cambridge Silicon Radio Limited 2014 - 2015.
 ******************************************************************************/

package com.csr.masterapp;

public interface TemperatureControllerInterface {

	void buttonUpClicked();
	void buttonDownClicked();
	void buttonTextClicked();
}
