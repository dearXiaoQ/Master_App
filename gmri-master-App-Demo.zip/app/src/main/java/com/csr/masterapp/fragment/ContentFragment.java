package com.csr.masterapp.fragment;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;

import com.csr.masterapp.BaseFragment;
import com.csr.masterapp.R;
import com.csr.masterapp.Recipe.RecipeListFragment;
import com.csr.masterapp.base.tab.appTabController;
import com.csr.masterapp.scene.CreateSceneUI;
import com.csr.masterapp.scene.SceneListFragment;
import com.csr.masterapp.device.AssociationFragment;
import com.csr.masterapp.device.DeviceListFragment;
import com.csr.masterapp.device.GroupAssignFragment;
import com.csr.masterapp.device.LightControlFragment;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;

/**
 * 项目名称：MasterApp
 * 类描述：主页的内容
 * 创建人：11177
 * 创建时间：2016/6/21 10:12
 * 修改人：11177
 * 修改时间：2016/6/21 10:12
 * 修改备注：
 */
public class ContentFragment extends BaseFragment implements RadioGroup.OnCheckedChangeListener, View.OnClickListener {

    private int currentPosition = 0;
    private int mSavedPosition = POSITION_INVALID;

    private Fragment mCurrentFragment;

    public static final int POSITION_INVALID = -1;
    public static final int POSITION_LIGHT_CONTROL = 0;
    public static final int POSITION_TEMP_CONTROL = 1;
    public static final int POSITION_ASSOCIATION = 2;
    public static final int POSITION_GROUP_CONFIG = 3;
    public static final int POSITION_NETWORK_SETTINGS = 4;
    public static final int POSITION_ABOUT = 5;
    public static final int POSITION_MAX = POSITION_ASSOCIATION;

    private static final String TAG ="ContentFragment";

    @ViewInject(R.id.Content_rg)
    public RadioGroup mRadioGroup;

    //private List<TabController> mPagerDatas;
    private int mCurrentTab;

    //顶部Btn显示控制
    @ViewInject(R.id.tab_rlyt_device)
    private RelativeLayout mButtonDevice;

    @ViewInject(R.id.tab_rlyt_scene)
    private RelativeLayout mButtonScene;

    @ViewInject(R.id.tab_rlyt_recipe)
    private RelativeLayout mButtonRecipe;

    //获取顶部Btn
    @ViewInject(R.id.device_btn_add)
    private Button mButtonAddDevice;

    @ViewInject(R.id.device_btn_log)
    private Button mButtonDeviceLog;

    @ViewInject(R.id.scene_btn_add)
    private Button mButtonAddScene;

    public FragmentManager mFragmentManager;
    private appTabController mAppTabController;

    private boolean mEnableNavigation;

    @Override
    protected View initView() {

        View view = View.inflate(mActivity, R.layout.content, null);

        ViewUtils.inject(this, view);

        //RadioGroup选中的监听
        mRadioGroup.setOnCheckedChangeListener(this);
        ((RadioButton) mRadioGroup.findViewById(R.id.content_rb_device)).setChecked(true);

        return view;
    }

    @Override
    protected void initData() {

        //头部选项
        mButtonAddScene.setOnClickListener(this);
        mButtonDeviceLog.setOnClickListener(this);
        mButtonAddDevice.setOnClickListener(this);
    }

    public void setNavigationEnabled(boolean enabled) {
        mEnableNavigation = enabled;
    }

    /**
     * 1.Radiogroup本身
     * 2.某一个选中的RadioButton的id
     */

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {

        mCurrentFragment = null;
        mCurrentTab = -1;
            switch (checkedId) {
                case R.id.content_rb_device:
                    mCurrentFragment = new DeviceListFragment();
                    mCurrentTab = POSITION_LIGHT_CONTROL;
                    mButtonDevice.setVisibility(View.VISIBLE);
                    mButtonRecipe.setVisibility(View.GONE);
                    mButtonScene.setVisibility(View.GONE);
                    break;
                case R.id.content_rb_scene:
                    mCurrentFragment = new SceneListFragment();
                    mButtonDevice.setVisibility(View.GONE);
                    mButtonRecipe.setVisibility(View.GONE);
                    mButtonScene.setVisibility(View.VISIBLE);
                    mCurrentTab = POSITION_TEMP_CONTROL;
                    break;
                case R.id.content_rb_recipe:
                    mCurrentFragment = new RecipeListFragment();
                    mButtonDevice.setVisibility(View.GONE);
                    mButtonRecipe.setVisibility(View.VISIBLE);
                    mButtonScene.setVisibility(View.GONE);
                    mCurrentTab = POSITION_ASSOCIATION;
                    break;
            }

        if (mCurrentFragment != null) {
            mFragmentManager = getActivity().getSupportFragmentManager();
            mFragmentManager.beginTransaction().addToBackStack(null).replace(R.id.listcontainer, mCurrentFragment).commit();
        }

        currentPosition = mCurrentTab;

    }

    public void switchMenu(int position) {

        if(mAppTabController != null){

            mButtonDevice.setVisibility(View.GONE);
            mButtonScene.setVisibility(View.GONE);
            mButtonRecipe.setVisibility(View.GONE);

            mAppTabController = new appTabController();

            mFragmentManager = getActivity().getSupportFragmentManager();
            mFragmentManager.beginTransaction().addToBackStack(null).replace(R.id.listcontainer, mAppTabController).commit();

            mAppTabController.switchMenu(position);
        }
    }

    public int getCurrentPosition(){
        return currentPosition;
    }

    /**
     * Saves which fragment is currently selected. Multiple calls will overwrite the last saved position.
     */
    public void savePosition() {
        mSavedPosition = currentPosition;
    }

    /**
     * Saves selected fragment position. Multiple calls will overwrite the last saved position.
     */
    public void savePosition(int position) {
        if (mSavedPosition > POSITION_MAX) {
            throw new IllegalArgumentException("Position is out of range.");
        }
        mSavedPosition = position;
    }

    /**
     * Restores the last saved selected fragment position.
     */
    public void restorePosition() {
        if (mSavedPosition == POSITION_INVALID) {
            throw new IllegalStateException("Position has not been previously saved.");
        }
//        if (mPager != null) {
//            mPager.setCurrentItem(mSavedPosition);
//            //bar.setSelectedNavigationItem(mSavedPosition);
//        }
    }

    /**
     * Refresh the configuration fragment if this is currently active.
     */
    public void refreshConfigFragment() {
        if (mCurrentFragment instanceof GroupAssignFragment) {
            GroupAssignFragment groupFragment = (GroupAssignFragment) mCurrentFragment;
            groupFragment.refreshUI();
        }
        else if (mCurrentFragment instanceof LightControlFragment) {
            LightControlFragment lightFragment = (LightControlFragment) mCurrentFragment;
            lightFragment.refreshUI();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.scene_btn_add:
                Intent intent = new Intent(mActivity, CreateSceneUI.class);
                startActivity(intent);
                return;
            case R.id.device_btn_log:
                getActivity().getSupportFragmentManager().beginTransaction().addToBackStack("").replace(R.id.main_container_content, new GroupAssignFragment()).commit();
                return;
            case R.id.device_btn_add:
                getActivity().getSupportFragmentManager().beginTransaction().addToBackStack("").replace(R.id.main_container_content, new AssociationFragment()).commit();
                return;
        }
    }
}
