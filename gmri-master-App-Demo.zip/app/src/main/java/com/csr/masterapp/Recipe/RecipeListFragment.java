
/******************************************************************************
 Copyright Cambridge Silicon Radio Limited 2014 - 2015.
 ******************************************************************************/

package com.csr.masterapp.Recipe;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.csr.masterapp.DeviceController;
import com.csr.masterapp.R;

/**
 * Fragment used to configure devices. Handles assigning devices to groups, get firmware version, remove a device or
 * group, rename a device or group and add a new group. Contains two side by side CheckedListFragment fragments.
 *
 */
public class RecipeListFragment extends Fragment {
    private static final String TAG = "DeviceListFragment";


    private View mRootView;

    private DeviceController mController;
    private Fragment mCurrentFragment;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        try {
            mController = (DeviceController) activity;
        }
        catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() + " must implement DeviceController callback interface.");
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (mRootView == null) {
            mRootView = inflater.inflate(R.layout.recipe_list_fragment, container, false);
        }

        mRootView.findViewById(R.id.rt1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager Manager = getActivity().getSupportFragmentManager();
                Manager.beginTransaction().addToBackStack(null).replace(R.id.main_container_content, new RecipeControlFragment()).commit();
            }
        });

        mRootView.findViewById(R.id.rt2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager Manager = getActivity().getSupportFragmentManager();
                Manager.beginTransaction().addToBackStack(null).replace(R.id.main_container_content, new RecipeControlFragment2()).commit();
            }
        });

        return mRootView;
    }

    @Override
    public void onResume() {
        super.onResume();
    }

}
