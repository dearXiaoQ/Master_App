
/******************************************************************************
 * Copyright Cambridge Silicon Radio Limited 2014 - 2015.
 ******************************************************************************/

package com.csr.masterapp.scene;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.csr.masterapp.R;
import com.csr.masterapp.database.DataBaseDataSource;
import com.csr.masterapp.scene.util.SceneItemModel;
import com.csr.masterapp.scene.util.SceneModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Fragment used to configure devices. Handles assigning devices to groups, get firmware version, remove a device or
 * group, rename a device or group and add a new group. Contains two side by side CheckedListFragment fragments.
 */
public class SceneListFragment extends Fragment implements AdapterView.OnItemClickListener, View.OnClickListener, CompoundButton.OnCheckedChangeListener, AdapterView.OnItemLongClickListener {
    private static final String TAG = "DeviceListFragment";


    private View mRootView;

    private DataBaseDataSource mDataBase;
    private ArrayList<SceneModel> mScenes;
    private SceneItemListAdpter mScenesAdpter;
    private SceneDetailListAdpter mScenesListAdpter;

    private ListView mListViewLeft;
    private TextView mSceneName;
    private CheckBox mSceneMsg;
    private Switch mSceneSwitch;
    private EditText editNameText;

    private Boolean isEditScene = false;//是否修改了当前场景 false:没有修改  true:有修改，弹出提示
    private Button mSaveScene;

    private SceneModel mCurrentScene;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mDataBase = new DataBaseDataSource(getActivity());
        initData();
    }

    private void initData() {
        mScenes = mDataBase.getAllSecnes();
        if(mScenes.size() == 0){
            Log.d(TAG, "initData: " + mScenes.size() );
            return;
        }
        Log.d(TAG, "initData: " + mScenes.size() );
        mCurrentScene = mScenes.get(0);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (mRootView == null) {
            mRootView = inflater.inflate(R.layout.scene_list_fragment, container, false);
        }

        mSceneName = (TextView) mRootView.findViewById(R.id.tv_scene_name);
        mSceneName.setOnClickListener(this);
        mRootView.findViewById(R.id.btn_save_name).setOnClickListener(this);
        editNameText = (EditText) mRootView.findViewById(R.id.edtTxt_name);
        mSceneMsg = (CheckBox) mRootView.findViewById(R.id.chk_msg);
        mSceneMsg.setOnCheckedChangeListener(this);
        mSceneSwitch = (Switch) mRootView.findViewById(R.id.switch_scene);
        mSceneSwitch.setOnCheckedChangeListener(this);
        mRootView.findViewById(R.id.tv_edit_name).setOnClickListener(this);
        mSaveScene = (Button) mRootView.findViewById(R.id.btn_save_scene);
        mSaveScene.setOnClickListener(this);

        mListViewLeft = (ListView) mRootView.findViewById(R.id.scene_lv_left);
        mScenesAdpter = new SceneItemListAdpter();
        mListViewLeft.setAdapter(mScenesAdpter);
        mListViewLeft.setOnItemClickListener(this);
        mListViewLeft.setChoiceMode(AbsListView.CHOICE_MODE_MULTIPLE_MODAL);//多选模式
        mListViewLeft.setMultiChoiceModeListener(new AccountMultiChoiceModeListener());//多选监听

        ListView mListViewScenes = (ListView) mRootView.findViewById(R.id.lv_list_scene);
        mScenesListAdpter = new SceneDetailListAdpter();
        mListViewScenes.setAdapter(mScenesListAdpter);
        mListViewScenes.setOnItemLongClickListener(this);

        if (mScenes.size() != 0) {
            mScenesListAdpter.changeDatas(mCurrentScene);
        }

        return mRootView;
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    @Override
    public void onResume() {
        super.onResume();
        mScenes = mDataBase.getAllSecnes();
        mScenesAdpter.notifyDataSetChanged();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_edit_name:
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle("修改场景名称");
                View diaName = View.inflate(getActivity(), R.layout.dialog_edit_name, null);
                final EditText editNameText = (EditText) diaName.findViewById(R.id.scene_et_name);
                editNameText.setHint(mCurrentScene.getName());
                editNameText.setText(mCurrentScene.getName());

                builder.setView(diaName);
                final EditText finalEditNameText = editNameText;
                builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (editNameText.getText().toString().trim().equals("")) {
                            Toast.makeText(getActivity(), "场景名称不能为空", Toast.LENGTH_LONG).show();
                        } else {
                            mCurrentScene.setName(editNameText.getText().toString());
                            isEditScene = true;
                            mScenesListAdpter.changeDatas(mCurrentScene);
                        }
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
                return;
            case R.id.btn_save_scene:
                if (mCurrentScene.getTasks().size() == 0) {
                    Toast.makeText(getActivity(), "请添加任务", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (mCurrentScene.getConditions().size() == 0) {
                    Toast.makeText(getActivity(), "请添加条件", Toast.LENGTH_SHORT).show();
                    return;
                }
                updateScenes(mCurrentScene);
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        //初始setChecked时禁止触发onCheckedChanged监听器
        if (buttonView.isPressed()) {

            if (buttonView.equals(mSceneSwitch)) {
                if (mCurrentScene != null) {
                    int value = isChecked ? 1 : 0;
                    mCurrentScene.setStatus(value);
                    mDataBase.updateSceneStatus(mCurrentScene.getSceneId(), value);
                    mScenesAdpter.notifyDataSetChanged();
                    Toast.makeText(getActivity(), isChecked ? "开启场景" : "关闭场景", Toast.LENGTH_SHORT).show();
                }
            }
            if (buttonView.equals(mSceneMsg)) {
                isEditScene = true;
                mCurrentScene.setIsSend(isChecked ? 1 : 0);
                mScenesListAdpter.changeDatas(mCurrentScene);
            }
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
        if (isEditScene) {
            final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setMessage("当前修改暂未保存，是否确定退出？");
            builder.setPositiveButton("保存并退出", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    updateScenes(mCurrentScene);
                    mCurrentScene = mScenes.get(position);
                    mScenesListAdpter.changeDatas(mCurrentScene);
                }
            });
            builder.setNeutralButton("不保存", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    isEditScene = false;
                    mScenes = mDataBase.getAllSecnes();
                    mCurrentScene = mScenes.get(position);
                    mScenesListAdpter.changeDatas(mCurrentScene);
                    mScenesAdpter.notifyDataSetChanged();
                }
            });
            builder.create().show();
        } else {
            mCurrentScene = mScenes.get(position);
            mScenesListAdpter.changeDatas(mCurrentScene);
        }
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {

        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setPositiveButton("删除", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                int size = mCurrentScene.getConditions().size();
                if (position > size) {
                    //删除任务
                    size = (size == 0 ? 1 : size);
                    mCurrentScene.getTasks().remove(position - 2 - size);
                } else {
                    //删除条件
                    mCurrentScene.getConditions().remove(position - 1);
                }
                isEditScene = true;
                mScenesListAdpter.changeDatas(mCurrentScene);
            }
        });
        builder.create().show();
        return false;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data != null) {
            SceneItemModel sceneItem = (SceneItemModel) data.getSerializableExtra("sceneItem");
            switch (resultCode) {
                case 0:
                    sceneItem.setType(0);
                    mCurrentScene.getConditions().add(sceneItem);
                    break;

                case 1:
                    sceneItem.setType(1);
                    mCurrentScene.getTasks().add(sceneItem);
                    break;
            }
            isEditScene = true;
            mScenesListAdpter.changeDatas(mCurrentScene);
            return;
        }
    }

    /**
     * 保存修改的场景数据,刷新列表数据
     */
    private void updateScenes(SceneModel Scene) {
        isEditScene = false;
        Boolean result = mDataBase.createOrUpdateScene(Scene);
        Toast.makeText(getActivity(), result ? "修改成功" : "修改失败", Toast.LENGTH_SHORT).show();
        if (result) { mSaveScene.setVisibility(View.GONE); }
        mScenes = mDataBase.getAllSecnes();
        mScenesAdpter.notifyDataSetChanged();
    }

    /**
     * 多选菜单
     */
    private class AccountMultiChoiceModeListener implements AbsListView.MultiChoiceModeListener {

        private ArrayList<Integer> sceneIds;

        public AccountMultiChoiceModeListener() {
            this.sceneIds = new ArrayList<Integer>();
        }

        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            mode.getMenuInflater().inflate(R.menu.contextual_menu_accountactivity, menu);
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {

        }

        @Override
        public void onItemCheckedStateChanged(ActionMode mode, int position, long id, boolean checked) {
            sceneIds.add(mScenes.get(position).getSceneId());
            mScenesAdpter.notifyDataSetChanged();
        }

        @Override
        public boolean onActionItemClicked(final ActionMode mode, MenuItem item) {
            switch (item.getItemId()) {
                case R.id.menu_remove_scene:
                    final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setMessage("确定删除选中的" + sceneIds.size() + "项场景");
                    builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (mDataBase.removeScenes(sceneIds)) {
                                Toast.makeText(getActivity(), "删除成功", Toast.LENGTH_SHORT).show();
                                initData();
                                mScenesAdpter.notifyDataSetChanged();
                                mScenesListAdpter.notifyDataSetChanged();
                            } else {
                                Toast.makeText(getActivity(), "删除失败", Toast.LENGTH_SHORT).show();
                            }

                            mode.finish();
                        }
                    });
                    builder.setNegativeButton("取消", null);
                    builder.create().show();
                    return true;
            }
            return false;
        }
    }

    class SceneDetailListAdpter extends BaseAdapter {

        public static final int VIEW_TYPE_CONDITION = 0;

        public static final int VIEW_TYPE_TASK = 1;

        public static final int VIEW_TYPE_HEADER = 2;

        public static final int VIEW_TYPE_EMPTY = 3;

        private static final int VIEW_TYPE_COUNT = 4;

        private List<SceneItemModel> taskData;
        private List<SceneItemModel> conditionData;

        private final LayoutInflater mInflater;

        private List<TypeItem> items;

        public SceneDetailListAdpter() {
            mInflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        class TypeItem {
            int itemType;

            private TypeItem(int itemType) {
                this.itemType = itemType;
            }
        }

        class SceneTypeItem extends TypeItem {
            SceneItemModel sceneItem;

            public SceneTypeItem(int type, SceneItemModel sceneItem) {
                super(type);
                this.sceneItem = sceneItem;
            }
        }

        class EmptyTypeItem extends TypeItem {
            public EmptyTypeItem(int type) {
                super(type);
            }
        }

        class HeaderTypeItem extends TypeItem {
            String label;

            public HeaderTypeItem(String label) {
                super(VIEW_TYPE_HEADER);
                this.label = label;
            }
        }

        class ViewHolder {

            View itemView;

            public ViewHolder(View itemView) {
                if (itemView == null) {
                    throw new IllegalArgumentException("itemView can not be null!");
                }
                this.itemView = itemView;
            }
        }

        class SceneViewHolder extends ViewHolder {

            TextView device;
            TextView name;
            View root;

            public SceneViewHolder(View view) {
                super(view);
                device = (TextView) view.findViewById(R.id.tv_list_name);
                name = (TextView) view.findViewById(R.id.tv_list_sec_name);
                root = view.findViewById(R.id.listview_root);
            }
        }

        class SceneEmptyHolder extends ViewHolder {

            public SceneEmptyHolder(View view) {
                super(view);
            }
        }

        class HeaderViewHolder extends ViewHolder {

            TextView label;
            ImageView addScene;

            public HeaderViewHolder(View view) {
                super(view);
                label = (TextView) view.findViewById(R.id.label);
                addScene = (ImageView) view.findViewById(R.id.btn_add_scene);
            }
        }

        private List<TypeItem> generateItems() {
            List<TypeItem> items = new ArrayList<TypeItem>();
            items.add(new HeaderTypeItem("启动条件"));
            if (conditionData.size() > 0) {
                for (SceneItemModel scene : conditionData) {
                    items.add(new SceneTypeItem(VIEW_TYPE_CONDITION, scene));
                    Log.d(TAG, "generateItems:condition " + scene.getDeviceName());
                }
            } else {
                items.add(new EmptyTypeItem(VIEW_TYPE_EMPTY));
            }
            items.add(new HeaderTypeItem("执行任务"));
            if (taskData.size() > 0) {
                for (SceneItemModel scene : taskData) {
                    items.add(new SceneTypeItem(VIEW_TYPE_TASK, scene));
                    Log.d(TAG, "generateItems:task " + scene.getDeviceName());
                }
            } else {
                items.add(new EmptyTypeItem(VIEW_TYPE_EMPTY));
            }
            return items;
        }

        public void changeDatas(SceneModel scene) {
            taskData = scene.getTasks();
            conditionData = scene.getConditions();
            mSceneName.setText(scene.getName());
            editNameText.setHint(scene.getName());
            mSceneMsg.setChecked(scene.getIsSend() == 1 ? true : false);
            mSceneSwitch.setChecked(scene.getStatus() == 1 ? true : false);
            this.items = generateItems();
            mSaveScene.setVisibility(isEditScene ? View.VISIBLE : View.GONE);
            mScenesListAdpter.notifyDataSetChanged();
        }

        @Override
        public int getItemViewType(int position) {
            if (items.get(position) != null) {
                return items.get(position).itemType;
            }
            return super.getItemViewType(position);
        }

        @Override
        public int getViewTypeCount() {
            return VIEW_TYPE_COUNT;
        }

        @Override
        public int getCount() {
            if (items != null) {
                return items.size();
            }
            return 0;
        }

        @Override
        public Object getItem(int position) {
            if (items != null && position > 0 && position < items.size()) {
                return items.get(position);
            }
            return null;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        public SceneItemModel getSceneByPosition(int position) {
            if (items.get(position).itemType == VIEW_TYPE_HEADER || items.get(position).itemType == VIEW_TYPE_EMPTY) {
                return null;
            } else {
                SceneTypeItem sceneTypeItem = (SceneTypeItem) items.get(position);
                return sceneTypeItem.sceneItem;
            }
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TypeItem item = items.get(position);
            ViewHolder viewHolder;
            if (convertView == null) {
                // 根据不同的viewType，初始化不同的布局
                switch (getItemViewType(position)) {
                    case VIEW_TYPE_HEADER:
                        viewHolder = new HeaderViewHolder(mInflater.inflate(
                                R.layout.scene_list_item_herder, null));
                        break;
                    case VIEW_TYPE_CONDITION:
                    case VIEW_TYPE_TASK:
                        viewHolder = new SceneViewHolder(mInflater.inflate(
                                R.layout.item_scene, null));
                        break;
                    case VIEW_TYPE_EMPTY:
                        viewHolder = new SceneEmptyHolder(mInflater.inflate(
                                R.layout.scene_list_item_empty, null));
                        break;
                    default:
                        throw new IllegalArgumentException("invalid view type : "
                                + getItemViewType(position));

                }
                // 缓存header与item视图
                convertView = viewHolder.itemView;
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }

            // 根据初始化的不同布局，绑定数据
            if (viewHolder instanceof HeaderViewHolder) {
                ((HeaderViewHolder) viewHolder).label.setText(String.valueOf(((HeaderTypeItem) item).label));

                if (((HeaderTypeItem) item).label.toString().equals("启动条件")) {
                    ((HeaderViewHolder) viewHolder).addScene.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(getActivity(), SceneItemUI.class);
                            intent.putExtra("type", 0);
                            startActivityForResult(intent, 0);
                        }
                    });
                }

                if (((HeaderTypeItem) item).label.toString().equals("执行任务")) {
                    ((HeaderViewHolder) viewHolder).addScene.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(getActivity(), SceneItemUI.class);
                            intent.putExtra("type", 1);
                            startActivityForResult(intent, 0);
                        }
                    });
                }

            } else if (viewHolder instanceof SceneViewHolder) {
                ((SceneViewHolder) viewHolder).device.setText(((SceneTypeItem) item).sceneItem.getDeviceName());
                ((SceneViewHolder) viewHolder).name.setText(((SceneTypeItem) item).sceneItem.getKey());
            }

            return convertView;
        }

    }


    class SceneItemListAdpter extends BaseAdapter {

        private int checkedBG;
        private int defaultBG;

        public SceneItemListAdpter() {
            this.defaultBG = getResources().getColor(R.color.transparent);
            this.checkedBG = getResources().getColor(R.color.selected_color);
        }

        @Override
        public int getCount() {
            if (mScenes != null) {
                return mScenes.size();
            }
            return 0;
        }

        @Override
        public Object getItem(int position) {
            if (mScenes != null) {
                return mScenes.get(position);
            }
            return null;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            ViewHolder holder = null;

            if (convertView == null) {
                holder = new ViewHolder();
                convertView = View.inflate(getActivity(), R.layout.item_list_scene, null);
                convertView.setTag(holder);

                holder.sceneName = (TextView) convertView.findViewById(R.id.tv_scene_name);
                holder.sceneStatu = (TextView) convertView.findViewById(R.id.tv_scene_statu);
                holder.sceneRoot = convertView.findViewById(R.id.listview_root);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }

            holder.sceneName.setText(mScenes.get(position).getName());
            String status = null;
            switch (mScenes.get(position).getStatus()) {
                case 0:
                    status = "已关闭";
                    break;
                case 1:
                    status = "已开启";
                    break;
                default:
                    return convertView;
            }
            holder.sceneStatu.setText(status);
            holder.sceneRoot.setBackgroundColor(defaultBG);
            if (mListViewLeft.getCheckedItemPositions().get(position)) {
                holder.sceneRoot.setBackgroundColor(checkedBG);
            }

            return convertView;
        }
    }

    class ViewHolder {
        TextView sceneName;
        TextView sceneStatu;
        View sceneRoot;
    }

}
