
/******************************************************************************
 Copyright Cambridge Silicon Radio Limited 2014 - 2015.
 ******************************************************************************/

package com.csr.masterapp.Recipe;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Spinner;
import android.widget.Toast;

import com.csr.masterapp.DeviceAdapter;
import com.csr.masterapp.DeviceController;
import com.csr.masterapp.R;
import com.csr.masterapp.TemperatureStatus;
import com.csr.masterapp.entities.Device;
import com.csr.masterapp.entities.SingleDevice;
import com.csr.mesh.SensorModelApi;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest;

import org.apache.http.entity.StringEntity;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.List;

/**
 * Fragment to show temperature control.
 * 
 */
public class RecipeControlFragment2 extends Fragment implements View.OnClickListener {
	
	// UI elements
	private Spinner mDeviceSpinner;

	// Controllers
	private DeviceAdapter mDeviceListAdapter;
	private DeviceController mController;

	// Fragment variables
	DecimalFormat mDecimalFactor = new DecimalFormat("0.0");
	
    private WebView mWebView;

    private static final String TAG = "RecipeControlFragment";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.recipe_control_fragment, container, false);

        rootView.findViewById(R.id.header_tv_title).setVisibility(View.GONE);
        rootView.findViewById(R.id.header_btn_ok).setVisibility(View.GONE);
        rootView.findViewById(R.id.header_iv_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().popBackStack();
            }
        });
        mDeviceSpinner = (Spinner)rootView.findViewById(R.id.spinnerSensorGroup);
        mWebView = (WebView) rootView.findViewById(R.id.webview);
        rootView.findViewById(R.id.receivetemp).setOnClickListener(this);
        rootView.findViewById(R.id.sendpower).setOnClickListener(this);
        return rootView;
    }
    
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mController = (DeviceController) activity;
        }
        catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() + " must implement DeviceController callback interface.");
        }
    }
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);    
        
    }
    
    @Override
    public void onStart() {
        super.onStart();
        if (mDeviceListAdapter == null) {
            mDeviceListAdapter = new DeviceAdapter(getActivity());
            mDeviceSpinner.setAdapter(mDeviceListAdapter);
            mDeviceSpinner.setOnItemSelectedListener(deviceSelect);
        }
        // enable continue scanning
        mController.setContinuousScanning(true);

        //webview
        mWebView.getSettings().setDefaultTextEncodingName("utf-8");
        mWebView.getSettings().setJavaScriptEnabled(true);
        mWebView.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        mWebView.addJavascriptInterface(new JavaScriptInterface(getActivity()), "RecipeObject");
        mWebView.loadUrl("file:///android_asset/index-recipesSoup.html");
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.sendpower:
                new JavaScriptInterface(getActivity()).sendPower(800, true);

                break;
            case R.id.receivetemp:
                String tempData = new JavaScriptInterface(getActivity()).getTempData();
                Toast.makeText(getActivity().getBaseContext(),"接收的温度数据是：" + tempData, Toast.LENGTH_SHORT ).show();

                break;
        }
    }

    public class JavaScriptInterface {
        private Context mContext;
        public JavaScriptInterface(Context context) {
            mContext = context;
        }

        @JavascriptInterface
        public void sendPower(final int power, final boolean onoff) {
            final String url = "http://192.168.1.222/hotPotControl/powerControl";
            HttpUtils utils = new HttpUtils();
            RequestParams params = new RequestParams();

            JSONObject obj = new JSONObject();
            try {
                obj.put("powerSw", onoff);
                obj.put("power", power);

                params.setBodyEntity(new StringEntity(obj.toString(),"UTF-8"));
            } catch (Exception e) {
            }

            utils.send(HttpRequest.HttpMethod.POST, url, params ,new RequestCallBack<String>() {

                @Override
                public void onSuccess(ResponseInfo<String> responseInfo) {
                    //场景 ecookpan -》 开抽烟机
                    if(onoff == true){
                        mController.setDesiredTemperature(0x000f);
                    }else{
                        mController.setDesiredTemperature(0x0000);
                    }

                    Log.d(TAG, "onSuccess: 发送的电磁炉功率是" + power);
                }
                @Override
                public void onFailure(HttpException error, String msg) {
                }
            });
        }

        @JavascriptInterface
        public String getTempData(){
            TemperatureStatus temperatureStatus = mController.getTemperatureStatus();
            if (temperatureStatus != null) {
                if (temperatureStatus.getCurrentTemperature() != Double.MIN_VALUE) {
                    Log.d(TAG, "getTempData: 接收到的温度数据是" + mDecimalFactor.format(temperatureStatus.getCurrentTemperature()) + "");
                    return mDecimalFactor.format(temperatureStatus.getCurrentTemperature()) + "";
                }
            }
            return null;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (mWebView != null) {
            try {
                mWebView.getSettings().setJavaScriptEnabled(false);
                mWebView.removeAllViews();
                mWebView.destroy();
            } catch (Exception e) {
            }
        }
        
        // disable continue scanning
        mController.setContinuousScanning(false);
        mController.setTemperatureListener(null);
    }

    @Override
    public void onStop() {
        super.onStop();
        mDeviceListAdapter.clear();
        JavaScriptInterface javaScriptInterface = new JavaScriptInterface(getActivity());
        javaScriptInterface.sendPower(0,false);
        if (mWebView != null) {
            try {
                mWebView.getSettings().setJavaScriptEnabled(false);
                mWebView.removeAllViews();
                mWebView.destroy();
            } catch (Exception e) {
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();

        List<Device> devices = mController.getDevicesByShortName("Ecookpan");
        for (Device dev : devices) {
            SingleDevice singleDevice = (SingleDevice)dev;
            mDeviceListAdapter.addDevice(singleDevice);
        }
        selectSpinnerDevice();
    }
	
    /**
     * Called when a new device is selected from the spinner.
     */
    private OnItemSelectedListener deviceSelect = new OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            deviceSelected(position);
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {
        }
    };
    
    /**
     * Event handler for when a new device is selected from the Spinner.
     * 
     * @param position
     *            Position within Spinner of selected device.
     */
    protected void deviceSelected(int position) {
        int deviceId = mDeviceListAdapter.getItemDeviceId(position);
        
        mController.setSelectedDeviceId(deviceId);
        mController.requestCurrentTemperature();
    }
    
    /**
     * Get the selected device id and set the spinner to it.
     */
    protected void selectSpinnerDevice() {
    	
        int selectedDeviceId = mController.getSelectedDeviceId();
        if (selectedDeviceId != Device.DEVICE_ID_UNKNOWN) {
        	Device dev = mController.getDevice(selectedDeviceId);
    		if (dev instanceof SingleDevice &&  ((SingleDevice)dev).isModelSupported(SensorModelApi.MODEL_NUMBER)) {
    			
    			int position = 0;
    			try {
    				position = mDeviceListAdapter.getDevicePosition(selectedDeviceId);
    			} catch (Exception e){}
    			mDeviceSpinner.setSelection(position, true);
    		}
    		else {
    			if (mDeviceListAdapter.getCount() > 0) {
                	mDeviceSpinner.setSelection(0);
                }
    		}
        }
        else {
            // No active device, so select the first device in the spinner if there is one.
            if (mDeviceListAdapter.getCount() > 0) {
            	mDeviceSpinner.setSelection(0);
            }
        }
    }
}
