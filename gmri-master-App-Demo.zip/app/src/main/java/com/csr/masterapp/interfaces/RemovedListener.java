
/******************************************************************************
 Copyright Cambridge Silicon Radio Limited 2014 - 2015.
 ******************************************************************************/

package com.csr.masterapp.interfaces;

public interface RemovedListener {
    public void onDeviceRemoved(int deviceId, boolean success);
}
